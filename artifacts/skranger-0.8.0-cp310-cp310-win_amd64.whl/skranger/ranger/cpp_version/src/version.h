#ifndef RANGER_VERSION
#define RANGER_VERSION "0.12.1"
#endif
